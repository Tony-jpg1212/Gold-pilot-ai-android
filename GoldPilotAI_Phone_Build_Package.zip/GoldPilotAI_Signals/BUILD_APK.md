# Build an installable Android APK

This project contains Android source code. It is not itself an APK. To produce an APK:

## Requirements
- A Windows, macOS or Linux computer
- Android Studio (current stable)
- Android SDK Platform 35 (or update compileSdk in `app/build.gradle.kts` to an installed SDK)
- Internet access for Gradle to download dependencies

## Build steps
1. Extract the `GoldPilotAI_Signals_Android_Starter.zip` archive.
2. Open the `android` folder in Android Studio.
3. Allow Gradle sync to complete and install any SDK components Android Studio requests.
4. Select **Build → Build Bundle(s) / APK(s) → Build APK(s)**.
5. When the build succeeds, choose **locate** in the notification.
6. The debug APK is normally at:
   `android/app/build/outputs/apk/debug/app-debug.apk`
7. Transfer that APK to your Android phone and open it. If Android asks, allow installation from that file manager/source.
8. For a shareable release, use **Build → Generate Signed Bundle / APK → APK**, create and securely back up your own signing key, then build a release APK.

## Current app limitations
- The dashboard currently shows placeholder/demo data until a real, verified signal service is connected.
- The backend is a starter API, not an AI market-prediction engine.
- The MT5 `.mq5` file is an illustrative indicator scaffold; it does not send trades.
- Live market data, a complete ICT/SMC rules engine, persistent signal history, push notifications, and production security still need implementation.
- Do not enter broker passwords into this app. This signals-only edition is not an MT5 auto-trader.

## Risk note
At a $100 reference balance, 0.5% equals $0.50 planned risk. Verify the actual JustMarkets XAUUSD contract/tick specifications and minimum volume. If the minimum lot would risk more than $0.50 at the proposed stop, skip the setup.
