# GoldPilot AI — Signals Edition

An original Android + MT5 signal-assistant starter for XAUUSD. This edition is **signals only**:
it does not connect to a trade execution API, send orders, or contain an auto-trading EA.

## User profile defaults
- Broker: JustMarkets
- Symbol: XAUUSD (confirm exact symbol/suffix in MT5)
- Reference balance: USD 100
- Planned risk: 0.5% = USD 0.50 per trade
- Analysis timeframes: H4/H1 bias; M15/M5 setup
- Manual execution in the official MT5 app/terminal

## Package contents
- `android/`: Kotlin Jetpack Compose dashboard starter with sample signal cards.
- `backend/`: FastAPI signal API with token authentication and validation.
- `mt5/`: MQL5 custom indicator scaffold for chart context/alerts (not an EA; cannot place orders).

## Important limitations
This is a starter project, not a finished production AI model or signed APK. The sample Android screen uses demo data. The API accepts signals from a future analysis engine; it does not itself predict the market. The MQL5 indicator contains simple illustrative conditions, not a complete or validated institutional ICT/SMC implementation.

Never treat a generated signal as guaranteed. Backtest and forward-test on demo first. Verify JustMarkets' XAUUSD contract size, tick size/value, volume min/step/max, stop-level and symbol suffix. Leverage does not determine appropriate risk.

## Run the backend locally
```bash
cd backend
python -m venv .venv
# activate the environment, then:
pip install -r requirements.txt
export GOLDPILOT_API_TOKEN='replace-with-a-long-random-secret'
uvicorn main:app --host 0.0.0.0 --port 8000
```
Use HTTPS, a persistent database, user authentication, rate limiting and audit logs before any public deployment.

## Android
Open the `android` directory in Android Studio. Use a current Android Studio/Gradle/Kotlin toolchain; sync and build an APK. Configure a production API URL and secure device authentication before release. Do not hardcode secrets in the APK.

## MT5
Copy `mt5/GoldPilotSignals.mq5` into `MQL5/Indicators/`, compile in MetaEditor and attach it to the broker's XAUUSD chart. Enable alerts as desired. This indicator only displays chart signals/context. It never places trades.

## Risk calculation
At $100 and 0.5%, planned cash risk is $0.50. Position size must be calculated from the actual entry-to-stop distance and the broker's symbol tick/contract specifications. If the minimum tradable volume risks more than $0.50, skip the trade rather than increasing risk.
