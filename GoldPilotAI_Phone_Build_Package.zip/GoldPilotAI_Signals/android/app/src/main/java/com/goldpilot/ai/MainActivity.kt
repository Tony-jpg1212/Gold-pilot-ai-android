package com.goldpilot.ai

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp

data class TradeSignal(
    val direction: String,
    val timeframe: String,
    val entry: String,
    val stop: String,
    val target: String,
    val setup: String,
    val status: String
)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { GoldPilotScreen() }
    }
}

@Composable
fun GoldPilotScreen() {
    val signals = listOf(
        TradeSignal("WAIT", "M15", "—", "—", "—",
            "Demo placeholder. Connect a verified signal feed to display live setups.", "NO LIVE SIGNAL")
    )
    MaterialTheme(colorScheme = darkColorScheme(
        primary = androidx.compose.ui.graphics.Color(0xFFD4AF37),
        background = androidx.compose.ui.graphics.Color(0xFF101114),
        surface = androidx.compose.ui.graphics.Color(0xFF1B1D22)
    )) {
        Scaffold(containerColor = MaterialTheme.colorScheme.background) { padding ->
            LazyColumn(
                modifier = Modifier.fillMaxSize().padding(padding).padding(18.dp),
                verticalArrangement = Arrangement.spacedBy(14.dp)
            ) {
                item {
                    Text("GOLDPILOT AI", style = MaterialTheme.typography.headlineMedium,
                        color = MaterialTheme.colorScheme.primary)
                    Text("XAUUSD • ICT / SMC SIGNALS", color = MaterialTheme.colorScheme.onSurfaceVariant)
                }
                item {
                    Card {
                        Column(Modifier.padding(16.dp)) {
                            Text("ACCOUNT RISK", style = MaterialTheme.typography.labelLarge)
                            Text("$100.00", style = MaterialTheme.typography.headlineLarge)
                            Text("0.5% planned risk = $0.50 per trade")
                            Text("JustMarkets • Manual MT5 execution")
                        }
                    }
                }
                item {
                    Text("MULTI-TIMEFRAME BIAS", style = MaterialTheme.typography.titleMedium)
                    Text("H4: Pending feed   •   H1: Pending feed")
                    Text("M15: Setup scan     •   M5: Entry confirmation")
                }
                item { Text("LATEST SIGNAL", style = MaterialTheme.typography.titleMedium) }
                items(signals.size) { index ->
                    val s = signals[index]
                    Card {
                        Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                            Text(s.direction, style = MaterialTheme.typography.headlineSmall,
                                color = MaterialTheme.colorScheme.primary)
                            Text("${s.timeframe} • ${s.status}")
                            Text("Entry: ${s.entry}    SL: ${s.stop}    TP: ${s.target}")
                            Text(s.setup)
                            Text("No live signal is being supplied by this demo screen.",
                                style = MaterialTheme.typography.bodySmall)
                        }
                    }
                }
                item {
                    Text("Risk rule: skip any setup where broker minimum lot size would risk more than $0.50.",
                        style = MaterialTheme.typography.bodyMedium)
                    Text("Signals are informational, not guarantees. Confirm every setup on your MT5 chart.",
                        style = MaterialTheme.typography.bodySmall)
                }
            }
        }
    }
}
