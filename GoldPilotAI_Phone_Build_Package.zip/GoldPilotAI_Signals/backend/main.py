from datetime import datetime, timezone
from typing import Literal, Optional
import os
from fastapi import FastAPI, Header, HTTPException
from pydantic import BaseModel, Field

TOKEN = os.getenv("GOLDPILOT_API_TOKEN", "")
app = FastAPI(title="GoldPilot AI Signals API", version="0.1.0")

class Signal(BaseModel):
    symbol: str = Field(pattern=r"^XAUUSD([._-]?[A-Za-z0-9]*)?$")
    direction: Literal["BUY", "SELL", "WAIT"]
    timeframe: Literal["M5", "M15"]
    entry: Optional[float] = Field(default=None, gt=0)
    stop_loss: Optional[float] = Field(default=None, gt=0)
    take_profit: Optional[float] = Field(default=None, gt=0)
    risk_percent: float = Field(default=0.5, gt=0, le=0.5)
    setup: str = Field(max_length=500)
    created_at: datetime = Field(default_factory=lambda: datetime.now(timezone.utc))

latest: Optional[Signal] = None

def auth(token: Optional[str]):
    if not TOKEN:
        raise HTTPException(503, "API token is not configured")
    if token != TOKEN:
        raise HTTPException(401, "Unauthorized")

@app.get("/health")
def health():
    return {"ok": True, "service": "GoldPilot AI Signals API"}

@app.get("/v1/signal")
def get_signal(x_api_token: Optional[str] = Header(default=None)):
    auth(x_api_token)
    return {"signal": latest.model_dump() if latest else None}

@app.post("/v1/signal")
def publish_signal(signal: Signal, x_api_token: Optional[str] = Header(default=None)):
    global latest
    auth(x_api_token)
    if signal.direction in ("BUY", "SELL"):
        if None in (signal.entry, signal.stop_loss, signal.take_profit):
            raise HTTPException(422, "BUY/SELL signals require entry, stop_loss and take_profit")
        if signal.direction == "BUY" and not signal.stop_loss < signal.entry < signal.take_profit:
            raise HTTPException(422, "BUY requires SL < entry < TP")
        if signal.direction == "SELL" and not signal.take_profit < signal.entry < signal.stop_loss:
            raise HTTPException(422, "SELL requires TP < entry < SL")
    latest = signal
    return {"accepted": True, "signal": signal.model_dump()}
