//+------------------------------------------------------------------+
//| GoldPilotSignals.mq5                                             |
//| Educational chart indicator scaffold. NEVER places trades.       |
//| Illustrative sweep + EMA bias conditions; not a full ICT engine.  |
//+------------------------------------------------------------------+
#property indicator_chart_window
#property indicator_buffers 2
#property indicator_plots   2
#property indicator_type1   DRAW_ARROW
#property indicator_type2   DRAW_ARROW
#property indicator_color1  clrLime
#property indicator_color2  clrTomato
#property indicator_label1  "GP Buy"
#property indicator_label2  "GP Sell"

input int Lookback = 12;
input int FastEMA = 20;
input int SlowEMA = 50;
input bool EnablePopupAlerts = true;
input double ReferenceBalance = 100.0;
input double RiskPercent = 0.5;

double BuyBuffer[], SellBuffer[];
int fastHandle, slowHandle;
datetime lastAlert=0;

int OnInit()
{
   SetIndexBuffer(0,BuyBuffer,INDICATOR_DATA);
   SetIndexBuffer(1,SellBuffer,INDICATOR_DATA);
   PlotIndexSetInteger(0,PLOT_ARROW,233);
   PlotIndexSetInteger(1,PLOT_ARROW,234);
   ArraySetAsSeries(BuyBuffer,true);
   ArraySetAsSeries(SellBuffer,true);
   fastHandle=iMA(_Symbol,PERIOD_M15,FastEMA,0,MODE_EMA,PRICE_CLOSE);
   slowHandle=iMA(_Symbol,PERIOD_M15,SlowEMA,0,MODE_EMA,PRICE_CLOSE);
   if(fastHandle==INVALID_HANDLE || slowHandle==INVALID_HANDLE) return INIT_FAILED;
   IndicatorSetString(INDICATOR_SHORTNAME,"GoldPilot AI Signals (illustrative)");
   return INIT_SUCCEEDED;
}

void OnDeinit(const int reason)
{
   if(fastHandle!=INVALID_HANDLE) IndicatorRelease(fastHandle);
   if(slowHandle!=INVALID_HANDLE) IndicatorRelease(slowHandle);
}

int OnCalculate(const int rates_total,const int prev_calculated,
                const datetime &time[],const double &open[],const double &high[],
                const double &low[],const double &close[],const long &tick_volume[],
                const long &volume[],const int &spread[])
{
   if(rates_total<Lookback+5) return 0;
   ArraySetAsSeries(time,true); ArraySetAsSeries(high,true);
   ArraySetAsSeries(low,true); ArraySetAsSeries(close,true);
   ArraySetAsSeries(open,true);
   ArrayInitialize(BuyBuffer,EMPTY_VALUE);
   ArrayInitialize(SellBuffer,EMPTY_VALUE);

   double f[3],s[3];
   ArraySetAsSeries(f,true); ArraySetAsSeries(s,true);
   if(CopyBuffer(fastHandle,0,0,3,f)<3 || CopyBuffer(slowHandle,0,0,3,s)<3)
      return prev_calculated;

   // Use closed candle index 1 to reduce intrabar repainting.
   int i=1;
   double priorLow=low[2], priorHigh=high[2];
   for(int j=2;j<=Lookback+1;j++)
   {
      priorLow=MathMin(priorLow,low[j]);
      priorHigh=MathMax(priorHigh,high[j]);
   }
   bool bullishBias=(f[1]>s[1]);
   bool bearishBias=(f[1]<s[1]);
   bool sellsideSweep=(low[i]<priorLow && close[i]>priorLow && close[i]>open[i]);
   bool buysideSweep=(high[i]>priorHigh && close[i]<priorHigh && close[i]<open[i]);

   if(bullishBias && sellsideSweep)
      BuyBuffer[i]=low[i]-10*_Point;
   if(bearishBias && buysideSweep)
      SellBuffer[i]=high[i]+10*_Point;

   if(EnablePopupAlerts && time[i]!=lastAlert)
   {
      if(BuyBuffer[i]!=EMPTY_VALUE)
      {
         Alert(_Symbol," illustrative BUY context on M15. Confirm MSS/FVG/SL/TP manually.");
         lastAlert=time[i];
      }
      else if(SellBuffer[i]!=EMPTY_VALUE)
      {
         Alert(_Symbol," illustrative SELL context on M15. Confirm MSS/FVG/SL/TP manually.");
         lastAlert=time[i];
      }
   }
   return rates_total;
}
